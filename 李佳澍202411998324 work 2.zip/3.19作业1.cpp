#include<iostream>
#include<string>
#include<windows.h>
using namespace std;
class Sporter {
    private:
    string _name;
    string _number;
    char _gender;
    double _second;
    public:
    Sporter(string name = "XXX", string num = "00000", char gen = 'm', double score = 0)
    : _name(name), _number(num), _gender(gen), _second(score){}
    double GetSecond() const {
        return _second;
    }
    void Show() const {
        cout << "Name:" << _name << endl;
        cout << "Number:" << _number << endl;
        cout << "Gender:" << _gender << endl;
        cout << "Second:" << _second << endl;
    }


};
Sporter FastSporter(Sporter *s,int size) {
    Sporter Fastone=s[0];
    for(int i=0;i<size;i++) {
        if(s[i].GetSecond()<Fastone.GetSecond()) {
            Fastone=s[i];
        }


    }
    return Fastone;

}

int main() {
    system("chcp 65001 > nul");
    Sporter spt1[10];
    cout << "The information of ten students in spt1:" << endl;
    for(int i=0;i<10;i++) {
        spt1[i].Show();
    }
    Sporter spt2[10] = {
        Sporter("张三", "00005", 'm', 13.2),
        Sporter("李四", "00012", 'm', 13.8),
        Sporter("王五", "00108", 'm', 12.7),
        Sporter("刘丽", "00022", 'f', 15.6),
        Sporter("赵康", "00115", 'm', 11.9),
        Sporter("张春生", "00059", 'm', 12.3),
        Sporter("周勇", "00001", 'm', 10.5),
        Sporter("王阳", "00072", 'f', 14.2),
        Sporter("刘燕", "00023", 'f', 13.5),
        Sporter("何平", "00007", 'f', 14.9)
    };
    cout << "The information of ten students in spt2:" << endl;
    for(int i=0;i<10;i++) {
        spt2[i].Show();
    }
    Sporter Fastest = FastSporter(spt2,10);
    cout << "The fastest one of ten students in spt2:" << endl;
    Fastest.Show();
    return 0;

}
// Created by MsOH_ on 25-3-19.
//
