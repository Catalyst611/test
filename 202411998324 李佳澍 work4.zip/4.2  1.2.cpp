#include<iostream>
#include<string>
#include<vector>
#include<ctime>

using namespace std;

class Fish {
private:
    string _name;
    string _color;
    int _weight = 100;
    static int _number;
    int last_day = 0;
    bool alive = true;
public:
    Fish(string name, string color, int weight = 100) : _name(name), _color(color) {
        _number++;
    }
    Fish(const Fish& f) {
        _name = f._name;
        _color = f._color;
        _weight = f._weight;
        _number = f._number;
        last_day = f.last_day;
        alive = f.alive;
    }
    static void shownumber() {
        cout << _number << endl;
    }
    static int getNumber() {
        return _number;
    }
    void feed(int today) {
        if (alive) {
            _weight += 10;
            last_day = today;
        }
        else {
            cout << "error" << endl;
        }
    }
    void isalive() {
        if (_weight > 0 && _weight < 300) {
            alive = true;
        }
        else {
            if (alive==true) {
                _number--;
            }
            alive = false;

        }
    }

    void hungry(int today) {
        if ((today - last_day) > 5) {
            _weight -= 10;
        }
    }
    bool getIsAlive() const {
        return alive;
    }
    string getName() const {
        return _name;
    }
    string getColor() const {
        return _color;
    }
    int getWeight() const {
        return _weight;
    }
    int getLastDay() const {
        return last_day;
    }
};

int Fish::_number = 0;

int main() {
    int N;
    cout << "Enter the number of the fish you want to have: (more than five)";
    cin >> N;
    while (N < 5) {
        cout << "error" << endl;
        cout << "Enter the number of the fish you want to have: (more than five)";
        cin >> N;
    }
    vector<Fish> fishList;
    for (int i = 0; i < N; i++) {
        string name, color;
        cout << "Please enter the name and color of the fish(number " << i + 1 << ") you want to have: ";
        cin >> name >> color;
        fishList.emplace_back(name, color);
    }
    cout << "Let's begin!" << endl;
    int today = 1;
    srand(time(nullptr));
    while (Fish::getNumber() > 0) {
        cout << "Now is day " << today << endl;
        int random = rand() % fishList.size();
        while (!fishList[random].getIsAlive()) {
            random = rand() % fishList.size();
        }
        fishList[random].feed(today);
        cout << "Day " << today << ", " << fishList[random].getName() << " is fed" << endl;
        for (int i = 0; i < N; i++) {
            if (fishList[i].getIsAlive()) {
                fishList[i].hungry(today);
            }
            fishList[i].isalive();
        }
        if (Fish::getNumber() <= 0) {
            cout << "All of the fish are dead!" << endl;
            return 0;
        }
        int count = 0;
        for (int i = 0; i < N; i++) {
            if (fishList[i].getIsAlive()) {
                count++;
            }
        }
        if (today % 10 == 0) {
            cout << "Day " << today << endl;
            cout << "Now you have " << count << " fish, their situations:" << endl;
            cout << "Name\t\tColor\t\tWeight\t\tLast Feeding Time" << endl;
            for (const auto& fish : fishList) {
                if (fish.getIsAlive()) {
                    cout << fish.getName() << "\t\t" << fish.getColor() << "\t\t"
                         << fish.getWeight() << "g\t\tDay " << fish.getLastDay() << endl;
                }
            }
        }

        char Choice;
        cout << "Do you want to continue? (Y/N) : ";
        cin >> Choice;

        if (Choice == 'N' || Choice == 'n') {
            cout << "Stop" << endl;
            return 0;
        }

        today++;
    }
    return 0;
}//
// Created by MsOH_ on 25-4-2.
//
//
// Created by MsOH_ on 25-4-2.
//
