#include<iostream>
#include<string>
#include<cmath>
using namespace std;
class Deposit {
    private:
    string _name;
    int _code;
    int _money;
    static double _rate;
    int _year;
    int _month;
    int _day;
    public:
    Deposit(string name, int code, int money, int year, int month, int day):_name(name),_code(code),_money(money),_year(year),_month(month),_day(day){}
    Deposit(const Deposit& d) {
        _name = d._name;
        _code = d._code;
        _money = d._money;
        _year = d._year;
        _month = d._month;
        _day = d._day;
    }
    string getname() {
        return _name;
    }
    int getcode() {
        return _code;
    }
    int getmoney() {
        return _money;
    }
    int getyear() {
        return _year;
    }
    int getmonth() {
        return _month;
    }
    int getday() {
        return _day;
    }
    void new_money() {
        _money = _money * (1 + _rate);
    }
    static void set_rate(double rate) {
        _rate = rate;
    }
    void money_now() {
        int n=0;
        if (_year<2024) {
            n+=6;
            if (_year<2023) {
                n+=12;
                n=n+1+(12-_month);
            }
            else {
                n=n+1+(12-_month);
            }
        }
        _money=_money*pow((1+_rate),n);
    }
};
double Deposit::_rate = 0.005;
int main() {

    Deposit account1("Zhang San", 1, 10000, 2022, 5, 1);
    Deposit account2("Li Si", 2, 20000, 2023, 7, 1);
    Deposit account3("Wang Wu", 3, 15000, 2023, 10, 1);
    Deposit account4("Zhao Liu", 4, 58000, 2022, 2, 1);
    Deposit account5("Zhou Qi", 5, 50000, 2022, 1, 1);

    account1.money_now();
    account2.money_now();
    account3.money_now();
    account4.money_now();
    account5.money_now();


    // Information of all accounts on July 1st, 2024
    std::cout << "Account information on July 1st, 2024:" << std::endl;
    std::cout << "Account number: " << account1.getcode() << ", Account holder: " << account1.getname() << ", Balance: " << account1.getmoney() << std::endl;
    std::cout << "Account number: " << account2.getcode() << ", Account holder: " << account2.getname() << ", Balance: " << account2.getmoney() << std::endl;
    std::cout << "Account number: " << account3.getcode() << ", Account holder: " << account3.getname() << ", Balance: " << account3.getmoney() << std::endl;
    std::cout << "Account number: " << account4.getcode() << ", Account holder: " << account4.getname() << ", Balance: " << account4.getmoney() << std::endl;
    std::cout << "Account number: " << account5.getcode() << ", Account holder: " << account5.getname() << ", Balance: " << account5.getmoney() << std::endl;

    // Calculate the balance on August 1st, 2024
    account1.new_money();
    account2.new_money();
    account3.new_money();
    account4.new_money();
    account5.new_money();

    // Information of all accounts on August 1st, 2024
    std::cout << "Account information on August 1st, 2024:" << std::endl;
    std::cout << "Account number: " << account1.getcode() << ", Account holder: " << account1.getname() << ", Balance: " << account1.getmoney() << std::endl;
    std::cout << "Account number: " << account2.getcode() << ", Account holder: " << account2.getname() << ", Balance: " << account2.getmoney() << std::endl;
    std::cout << "Account number: " << account3.getcode() << ", Account holder: " << account3.getname() << ", Balance: " << account3.getmoney() << std::endl;
    std::cout << "Account number: " << account4.getcode() << ", Account holder: " << account4.getname() << ", Balance: " << account4.getmoney() << std::endl;
    std::cout << "Account number: " << account5.getcode() << ", Account holder: " << account5.getname() << ", Balance: " << account5.getmoney() << std::endl;

    // Adjust the monthly interest rate to 0.4% this month
    Deposit::set_rate(0.004);

    // Calculate the balance on September 1st, 2024
    account1.new_money();
    account2.new_money();
    account3.new_money();
    account4.new_money();
    account5.new_money();

    // Information of all accounts on September 1st, 2024
    std::cout << "Account information on September 1st, 2024:" << std::endl;
    std::cout << "Account number: " << account1.getcode() << ", Account holder: " << account1.getname() << ", Balance: " << account1.getmoney() << std::endl;
    std::cout << "Account number: " << account2.getcode() << ", Account holder: " << account2.getname() << ", Balance: " << account2.getmoney() << std::endl;
    std::cout << "Account number: " << account3.getcode() << ", Account holder: " << account3.getname() << ", Balance: " << account3.getmoney() << std::endl;
    std::cout << "Account number: " << account4.getcode() << ", Account holder: " << account4.getname() << ", Balance: " << account4.getmoney() << std::endl;
    std::cout << "Account number: " << account5.getcode() << ", Account holder: " << account5.getname() << ", Balance: " << account5.getmoney() << std::endl;

    // Calculate the balance on October 1st, 2024
    account1.new_money();
    account2.new_money();
    account3.new_money();
    account4.new_money();
    account5.new_money();

    // Information of all accounts on October 1st, 2024
    std::cout << "Account information on October 1st, 2024:" << std::endl;
    std::cout << "Account number: " << account1.getcode() << ", Account holder: " << account1.getname() << ", Balance: " << account1.getmoney() << std::endl;
    std::cout << "Account number: " << account2.getcode() << ", Account holder: " << account2.getname() << ", Balance: " << account2.getmoney() << std::endl;
    std::cout << "Account number: " << account3.getcode() << ", Account holder: " << account3.getname() << ", Balance: " << account3.getmoney() << std::endl;
    std::cout << "Account number: " << account4.getcode() << ", Account holder: " << account4.getname() << ", Balance: " << account4.getmoney() << std::endl;
    std::cout << "Account number: " << account5.getcode() << ", Account holder: " << account5.getname() << ", Balance: " << account5.getmoney() << std::endl;

    // Calculate the balance on November 1st, 2024
    account1.new_money();
    account2.new_money();
    account3.new_money();
    account4.new_money();
    account5.new_money();

    // Information of all accounts on November 1st, 2024
    std::cout << "Account information on November 1st, 2024:" << std::endl;
    std::cout << "Account number: " << account1.getcode() << ", Account holder: " << account1.getname() << ", Balance: " << account1.getmoney() << std::endl;
    std::cout << "Account number: " << account2.getcode() << ", Account holder: " << account2.getname() << ", Balance: " << account2.getmoney() << std::endl;
    std::cout << "Account number: " << account3.getcode() << ", Account holder: " << account3.getname() << ", Balance: " << account3.getmoney() << std::endl;
    std::cout << "Account number: " << account4.getcode() << ", Account holder: " << account4.getname() << ", Balance: " << account4.getmoney() << std::endl;
    std::cout << "Account number: " << account5.getcode() << ", Account holder: " << account5.getname() << ", Balance: " << account5.getmoney() << std::endl;

    // Calculate the balance on December 1st, 2024
    account1.new_money();
    account2.new_money();
    account3.new_money();
    account4.new_money();
    account5.new_money();

    // Information of all accounts on December 1st, 2024
    std::cout << "Account information on December 1st, 2024:" << std::endl;
    std::cout << "Account number: " << account1.getcode() << ", Account holder: " << account1.getname() << ", Balance: " << account1.getmoney() << std::endl;
    std::cout << "Account number: " << account2.getcode() << ", Account holder: " << account2.getname() << ", Balance: " << account2.getmoney() << std::endl;
    std::cout << "Account number: " << account3.getcode() << ", Account holder: " << account3.getname() << ", Balance: " << account3.getmoney() << std::endl;
    std::cout << "Account number: " << account4.getcode() << ", Account holder: " << account4.getname() << ", Balance: " << account4.getmoney() << std::endl;
    std::cout << "Account number: " << account5.getcode() << ", Account holder: " << account5.getname() << ", Balance: " << account5.getmoney() << std::endl;

    return 0;
}
//
// Created by MsOH_ on 25-4-2.
//
