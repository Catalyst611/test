#include<iostream>
#include<string>
#include<vector>
using namespace std;
class FamElec {
    private:
    string _name;
    string _room;
    int _elec[12];
    static int _stepAmount() {
        return 2880;
    }
    static double _price() {
        return 0.4884;
    }
    static double _stepPrice() {
        return 0.5383;
    }
    public:
    FamElec(string name, string room, int* array): _name(name), _room(room) {
        for (int i = 0; i < 12; ++i) {
            _elec[i] = array[i];
        }
    }
    void show() const {
        cout << "Name: " << _name << "  Room" << _room << endl;
        cout << "Electricity consumption for 12 months" ;
        for (int i = 0; i < 12; i++) {
            cout << _elec[i] << " ";
        }
    }
    friend int TotalElec(const FamElec& fam);
    friend double AveElec(const FamElec& fam);
    friend double Cost(const FamElec& fam);
};

int TotalElec(const FamElec& fam) {
    int total = 0;
    for (int i = 0; i < 12; i++) {
        total += fam._elec[i];
    }
    return total;
}
double AveElec(const FamElec& fam) {
    double total = static_cast<double>(TotalElec(fam));
    return total / 12.0;
}
double Cost(const FamElec& fam) {
    int total = TotalElec(fam);
    if (total >fam._stepAmount()) {
        return 2880 * FamElec::_price() + (total - 2880) * FamElec::_stepPrice();
    }
    else {
        return total*fam._price();
    }
}
int main() {
    int n;
    cout << "Enter number of users: ";
    cin >> n;
    vector<FamElec> fam;
    string name,room;
    int a[12];
    for (int i = 0; i < n; ++i) {
        cout << "Enter name" << endl;
        cin >> name;
        cout << "Enter room" << endl;
        cin >> room;
        cout << "Enter electricity consumption for 12 months respectively: ";
        for (int j = 0; j < 12; ++j) {
            cin >> a[j];
        }
        fam.emplace_back(name, room, a);
    }
    cout << "User electricity consumption information:" << endl;
    //for 循环，利用const auto& family : fam遍历
    for (const auto& family : fam) {
        family.show();
        //设置输出浮点数时的精度,保留小数点后2位
        cout.precision(2);
        //使即使小数部分为0也输出两位小数
        cout << fixed;
        cout << "Average monthly electricity consumption: " << AveElec(family) << "    Annual electricity consumption: " << TotalElec(family) << "        Annual electricity bill: " << Cost(family) << endl;
    }

    return 0;
}


//
// Created by MsOH_ on 25-4-9.
//
