#include<iostream>
#include<string>
#include<fstream>
#include<vector>
using namespace std;
class FamElec {
    private:
    string _name;
    string _room;
    int _elec[12];
    static int _stepAmount() {
        return 2880;
    }
    static double _price() {
        return 0.4884;
    }
    static double _stepPrice() {
        return 0.5383;
    }
    public:
    FamElec(string name, string room, int* array): _name(name), _room(room) {
        for (int i = 0; i < 12; ++i) {
            _elec[i] = array[i];
        }
    }
    void show() const {
        cout << "Name: " << _name << "  Room" << _room << endl;
        cout << "Electricity consumption for 12 months" ;
        for (int i = 0; i < 12; i++) {
            cout << _elec[i] << " ";
        }
    }
    friend int TotalElec(const FamElec& fam);
    friend double AveElec(const FamElec& fam);
    friend double Cost(const FamElec& fam);
};

int TotalElec(const FamElec& fam) {
    int total = 0;
    for (int i = 0; i < 12; i++) {
        total += fam._elec[i];
    }
    return total;
}
double AveElec(const FamElec& fam) {
    double total = static_cast<double>(TotalElec(fam));
    return total / 12.0;
}
double Cost(const FamElec& fam) {
    int total = TotalElec(fam);
    if (total >fam._stepAmount()) {
        return 2880 * FamElec::_price() + (total - 2880) * FamElec::_stepPrice();
    }
    else {
        return total*fam._price();
    }
}
int main() {
    ifstream inFile("in.txt");
    if (!inFile) {
        cerr << "Could not open in.txt" << endl;
        return 1;
    }

    vector<FamElec> fam;
    string name, room;
    int a[12];

    for (int i = 0; i < 100; ++i) {
        inFile >> name >> room;
        for (int j = 0; j < 12; ++j) {
            inFile >> a[j];
        }
        fam.emplace_back(name, room, a);
    }

    cout << "User electricity consumption information:" << endl;
    for (const auto& family : fam) {
        family.show();
        cout.precision(2);
        cout << fixed;
        cout << "Average monthly electricity consumption: " << AveElec(family)
             << "    Annual electricity consumption: " << TotalElec(family)
             << "        Annual electricity bill: " << Cost(family) << endl;
    }

    inFile.close();

    return 0;
}


//
// Created by MsOH_ on 25-4-9.
//
//
// Created by MsOH_ on 25-4-9.
//
