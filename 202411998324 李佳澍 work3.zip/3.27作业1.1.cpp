#include <iostream>
#include<cmath>
#include <iomanip>
#include <fstream>
#include <vector>
using namespace std;

class Point {
private:
    double _x, _y;
public:
    Point (double x=0, double y=0);
    Point (const Point &p);
    double getx() const;
    double gety() const;
    void setx(double x);
    void sety(double y);
    void show() const;
};

Point::Point(double x,double y) {
    _x=x;
    _y=y;
}

Point::Point(const Point &p) {
    _x=p._x;
    _y=p._y;
}

void Point::setx(double x) {
    _x=x;
}

void Point::sety(double y) {
    _y=y;
}

double Point::getx() const {
    return _x;
}

double Point::gety() const {
    return _y;
}

void Point::show() const {
    cout << "point:" << "(" << _x << ", " << _y << ")" << endl;
}

class Line {
private:
    Point _p1, _p2;
    double _length;
public:
    Line(Point p1, Point p2);
    Line(const Line& l);
    double getLength() const;
};

Line::Line(Point p1, Point p2) :_p1(p1),_p2(p2){
    double x=_p1.getx()-_p2.getx();
    double y=_p1.gety()-_p2.gety();
    _length=sqrt(x*x+y*y);
}

Line::Line(const Line& l): _p1(l._p1), _p2(l._p2){
    _length=l._length;
}

double Line::getLength() const {
    return _length;
}

class Triangle {
private:
    Point _p1, _p2, _p3;
    double _length1, _length2, _length3;
public:
    Triangle (Point p1, Point p2, Point p3);
    bool xingcheng() const;
    bool rt() const;
    bool dengbian() const;
    bool dengyao() const;
    double mianji() const;
    double zhouchang() const;
    void showinfo() const;
};

Triangle::Triangle(Point p1, Point p2, Point p3):_p1(p1),_p2(p2),_p3(p3) {
    Line line1(_p1, _p2);
    Line line2(_p3, _p1);
    Line line3(_p2, _p3);
    _length1 = line1.getLength();
    _length2 = line2.getLength();
    _length3 = line3.getLength();
}

bool Triangle::xingcheng() const {
    return(_length1 < _length2 + _length3 && _length2 < _length1 + _length3 && _length3 < _length1 + _length2);
}

bool Triangle::rt() const {
    double squared_length1 = _length1 * _length1;
    double squared_length2 = _length2 * _length2;
    double squared_length3 = _length3 * _length3;
    const double jingduzhi = 1e-9;
    return(abs(squared_length1 - squared_length2 - squared_length3) < jingduzhi ||
           abs(squared_length2 - squared_length1 - squared_length3) < jingduzhi ||
           abs(squared_length3 - squared_length1 - squared_length2) < jingduzhi);
}

bool Triangle::dengbian() const {
    return(_length1 == _length2 && _length2 == _length3 && _length3 == _length1);
}

bool Triangle::dengyao() const {
    return(_length1 == _length3 || _length3 == _length2 || _length2 == _length1);
}

double Triangle::mianji() const {
    double c = (_length1 + _length2 + _length3) / 2;
    return sqrt(c * (c - _length1) * (c - _length2) * (c - _length3));
}

double Triangle::zhouchang() const {
    return _length1 + _length2 + _length3;
}

void Triangle::showinfo() const {
    cout << fixed << setprecision(3);
    cout << _p1.getx() << " " << _p1.gety() << " "
         << _p2.getx() << " " << _p2.gety() << " "
         << _p3.getx() << " " << _p3.gety();
    if (xingcheng()) {
        cout << "  " << "Could Form" << endl;
        cout << "Triangle:" << endl;
        _p1.show();

        _p2.show();

        _p3.show();

        if (dengbian()) {
            cout << "equilateral triangle" << endl;
        }
        if (dengyao()) {
            cout << "isosceles triangle" << endl;
        }
        if (rt()) {
            cout << "right triangle" << endl;
        }
        cout << "area=" << mianji() << endl;
        cout << "perimeter=" << zhouchang() << endl;
    }
    else {
        cout << "  " << "Could Not Form" << endl;
    }
}
// 写入三角形数据到文件
void writeTrianglesToFile(const vector<vector<double>>& trianglesData, const string& filename) {
    ofstream outFile(filename);
    if (!outFile.is_open()) {
        cerr << "Could not open file for writing: " << filename << endl;
        return;
    }
    for (const auto& triangle : trianglesData) {
        for (double coord : triangle) {
            outFile << coord << " ";
        }
        outFile << endl;
    }
    outFile.close();
}

int main() {
    // 示例三角形数据
    vector<vector<double>> trianglesData = {
        {0, 0, 3, 4, 4, 0},
        {0, 0, 2, 2, 0, 2},
        {2, 0, 5, 0, 3.5, 2.6},
        {-2, 3, 2, 6, 2, 2},
        {0, 0, 0, 0, 6, 8},
        {-2, 0, 2, 0, 0, 2},
        {-1, 0, 0, 0, 0, 4},
        {-2, 0, 0, 2, 3, 5},
        {3, 4, 8, 7, 5, 9},
        {5, 2, 7, 4, 5, 2}
    };

    // 写入数据到文件
    writeTrianglesToFile(trianglesData, "triangle.txt");

    // 从文件读取数据
    ifstream file("triangle.txt");
    if (!file.is_open()) {
        cerr << "Could Not Open The File: triangle.txt!" << endl;
        return 1;
    }
    vector<Triangle> triangles;

    while (true) {
        double x1, y1, x2, y2, x3, y3;
        if (!(file >> x1 >> y1 >> x2 >> y2 >> x3 >> y3)) {
            break;
        }
        Point p1(x1, y1);
        Point p2(x2, y2);
        Point p3(x3, y3);
        triangles.emplace_back(p1, p2, p3);
    }

    file.close();

    for (const auto& triangle : triangles) {
        triangle.showinfo();
    }

    return 0;
}    //
// Created by MsOH_ on 25-3-27.
//
