#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

class Date {
private:
    unsigned year;
    unsigned month;
    unsigned day;

    // 判断是否为闰年
    bool isLeapYear(int year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }

    // 计算从 1900 年 1 月 1 日到指定日期的总天数
    int daysSince1900(int year, int month, int day) {
        int days = 0;
        // 计算 1900 年到指定年份前一年的总天数
        for (int y = 1900; y < year; ++y) {
            days += isLeapYear(y) ? 366 : 365;
        }

        // 每个月的天数，二月根据是否闰年处理
        int monthDays[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        if (isLeapYear(year)) {
            monthDays[1] = 29;
        }

        // 计算指定年份到指定月份前一个月的总天数
        for (int m = 0; m < month - 1; ++m) {
            days += monthDays[m];
        }

        // 加上指定月份的天数
        days += day;

        return days;
    }

public:
    //输入部分时间
    void setYear(unsigned year) {
        this->year = year;
    }

    void setMonth(unsigned month) {
        this->month = month;
    }

    void setDay(unsigned day) {
        this->day = day;
    }
    //输出部分时间

    unsigned getYear() {
        return year;
    }

    unsigned getMonth() {
        return month;
    }

    unsigned getDay() {
        return day;
    }
    //写得过于复杂的判断函数（分类判断）

    bool valid() {
        if (year < 1900 || month < 1 || month > 12 || day < 1) {
            return false;
        }
        int monthDays[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
            monthDays[1] = 29;
        }
        return day <= monthDays[month - 1];
    }

    void display() {
        cout << getYear() << "-" << getMonth() << "-" << getDay() << endl;
    }
    //输出日历表

    void displaymonthcalender() {
        string monthNames[] = {"January", "February", "March", "April", "May", "June",
                               "July", "August", "September", "October", "November", "December"};
        cout << setw(20) << monthNames[month - 1] << " " << year << endl;
        cout << setw(5) << "Sun" << setw(5) << "Mon" << setw(5) << "Tue" << setw(5) << "Wed"
             << setw(5) << "Thu" << setw(5) << "Fri" << setw(5) << "Sat" << endl;

        // 计算该月第一天是星期几
        Date firstDayOfMonth;
        firstDayOfMonth.setYear(year);
        firstDayOfMonth.setMonth(month);
        firstDayOfMonth.setDay(1);
        int weekdayOfFirstDay = (firstDayOfMonth.daysSince1900(year, month, 1) - 1) % 7;

        // 输出该月第一天前的空白
        for (int i = 0; i < weekdayOfFirstDay; ++i) {
            cout << setw(5) << " ";
        }

        // 每个月的天数，二月根据是否闰年处理
        int monthDays[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        if (isLeapYear(year)) {
            monthDays[1] = 29;
        }
        int daysInMonth = monthDays[month - 1];

        // 输出该月的日期
        for (int day = 1; day <= daysInMonth; ++day) {
            cout << setw(5) << day;
            if ((day + weekdayOfFirstDay) % 7 == 0) {
                cout << endl;
            }
        }
        cout << endl;
    }

    // 计算星期几
    string getWeekday() {
        int days = daysSince1900(year, month, day);
        // 1900 年 1 月 1 日是星期一，所以总天数对 7 取余，0 表示星期一
        int weekday = (days - 1) % 7;
        string weekdayNames[] = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
        return weekdayNames[weekday];
    }

    // 输出年历表
    void displayyearcalender() {
        string monthNames[] = {"January", "February", "March", "April", "May", "June",
                               "July", "August", "September", "October", "November", "December"};
        int monthDays[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        if (isLeapYear(year)) {
            monthDays[1] = 29;
        }

        // 分四行输出，每行三个月份
        for (int row = 0; row < 4; ++row) {
            // 输出月份名称
            for (int col = 0; col < 3; ++col) {
                int monthIndex = row * 3 + col;
                cout << setw(24) << monthNames[monthIndex] << " " << year << setw(1000);
            }
            cout << endl;

            // 输出星期表头
            for (int col = 0; col < 3; ++col) {
                cout << setw(5) << "Sun" << setw(5) << "Mon" << setw(5) << "Tue" << setw(5) << "Wed"
                     << setw(5) << "Thu" << setw(5) << "Fri" << setw(5) << "Sat" << setw(5);
            }
            cout << endl;

            // 输出每个月的日期日历表
            // 利用每行都是同一周来输出
            int maxWeeks = 6;
            for (int week = 0; week < maxWeeks; ++week) {
                for (int col = 0; col < 3; ++col) {
                    int monthIndex = row * 3 + col;
                    Date firstDayOfMonth;
                    firstDayOfMonth.setYear(year);
                    firstDayOfMonth.setMonth(monthIndex + 1);
                    firstDayOfMonth.setDay(1);
                    int weekdayOfFirstDay = (firstDayOfMonth.daysSince1900(year, monthIndex + 1, 1) - 1) % 7;
                    int daysInThisMonth = monthDays[monthIndex];

                    for (int dayOfWeek = 0; dayOfWeek < 7; ++dayOfWeek) {
                        int dayNumber = week * 7 + dayOfWeek - weekdayOfFirstDay + 1;
                        if (dayNumber < 1 || dayNumber > daysInThisMonth) {
                            cout << setw(5) << " ";
                        } else {
                            cout << setw(5) << dayNumber;
                        }
                    }
                    cout << setw(5);
                }
                cout << endl;
            }
            cout << endl;
        }
    }
};

int main() {
    Date date;
    int a;
    cout << "Type the year:" << endl;
    cin >> a;
    date.setYear(a);
    date.displayyearcalender();
    return 0;
}    //
// Created by MsOH_ on 25-3-14.
//
